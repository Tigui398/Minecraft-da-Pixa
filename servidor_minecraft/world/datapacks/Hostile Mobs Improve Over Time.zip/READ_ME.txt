- made by KNIZE_1007

- licence things:
- you can modify for personal uses ONLY
- using on servers is allowed
- you cannot redistribute in any form
- you cannot take credit for the making of this datapack
- you can use in videos/other stuff if proper credit is given (link in description, said in video, etc.) (also let me know if are using it for a video, i would be glad to see it!)
- you cannot download from unofficial sources (currently officially on modrinth and planetminecraft)

- credit goes to Blazeandcave's Advancements Pack, some advancements were used as templates for my advancements, link: https://www.planetminecraft.com/data-pack/blazeandcave-s-advancements-pack-1-12/

- Questions, suggestions, ideas, bug reports? discord link: https://discord.gg/PQFMab5ySp